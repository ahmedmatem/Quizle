﻿namespace Quizle.Infrastructure.Data.Types
{
    public enum QuizStatus
    {
        Draft = 0, Published = 1, Active = 2, Closed = 3
    }
}
