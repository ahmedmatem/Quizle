﻿namespace Quizle.Infrastructure.Data.Types
{
    public enum QuestionType
    {
        MultipleChoice = 0, Numeric = 1, ShortText = 2
    }
}
