﻿namespace Quizle.Infrastructure.Data.Entities
{
    public class GroupStudent
    {
        public string StudentId { get; set; } = null!;

        public string GroupId { get; set; } = null!;
    }
}
